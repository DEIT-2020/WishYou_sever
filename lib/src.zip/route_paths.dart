import 'package:angular_router/angular_router.dart';
import 'dashboard_component.template.dart' as dashboard_template;

class RoutePaths {
  static final heroes = RoutePath(path: 'heroes');
  static final dashboard = RouteDefinition(
  routePath: RoutePaths.dashboard,
  component: dashboard_template.DashboardComponentNgFactory,
);
// ···
static final all = <RouteDefinition>[
  dashboard,
  // ···
];
}

